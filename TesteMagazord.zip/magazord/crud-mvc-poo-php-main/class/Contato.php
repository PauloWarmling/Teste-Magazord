<?php
namespace Application\Model;
use Doctrine\ORM\Mapping AS ORM;
/**
 * @ORM\Entity
 * @ORM\Table(name="contato",uniqueConstraints={@ORM\UniqueConstraint(name="id", columns={"id", "tipo", "descricao", "idPessoa"})})
 */
class Contato {

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;
    /**
     * @ORM\Column(type="text")
     */
    private $tipo;
    /**
     * @ORM\Column(type="text")
     */
    private $descricao;

    /**
     * @ORM\Column(type="integer")
     */
    private $idPessoa;

    private $nomePessoa;

    public function getId() {
        return $this->id;
    }
    public function setId($id) {
        $this->id = $id;
    }
    public function getTipo() {
        return $this->tipo;
    }
    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }
    public function getDescricao() {
        return $this->descricao;
    }
    public function setDescricao($descricao) {
        $this->descricao = $descricao;
    }

    public function getIdPessoa() {
        return $this->idPessoa;
    }
    public function setIdPessoa($idPessoa) {
        $this->idPessoa = $idPessoa;
    }

    public function getNomePessoa() {
        return $this->nomePessoa;
    }
    public function setNomePessoa($nomePessoa) {
        $this->nomePessoa = $nomePessoa;
    }
}

?>