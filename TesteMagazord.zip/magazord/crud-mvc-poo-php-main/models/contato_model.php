<?php

    require_once ("C:/xampp\htdocs/magazord 2/crud-mvc-poo-php-main/configuration/connect.php");
    require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/models/pessoa_model.php");
    require_once ("C:/xampp\htdocs/magazord 2/crud-mvc-poo-php-main/class/Contato.php");
    require_once "../vendor/autoload.php";

    use Doctrine\ORM\Tools\Setup;
    use Doctrine\ORM\EntityManager;

    class ContatoModel extends Connect{
        
        private $table;
        private $entityManager;

        function __construct(){
            parent::__construct();

            $this->pessoaModel = new PessoaModel();
            $paths = [__DIR__."/src/Entities"];
            $isDevMode = true;
            $config = Setup::createAnnotationMetadataConfiguration($paths, $isDevMode, null, null, false);

            //aqui configuramos a conexão com banco de dados
            $params = [
                'url' => "mysql://".USER.":".PASSWORD."@".HOST."/".DBNAME
            ];
            $this->entityManager = EntityManager::create($params, $config);
            $this->table = "contato";
        }

        public function getAll(){
            $contato = $this->entityManager->getRepository('\Application\Model\Contato');
            $resultQuery = $this->setaNomePessoas($contato->findAll());
            return $resultQuery;
        }

        private function setaNomePessoas($contatos) {
            foreach($contatos as $contato) {
                $pessoa = $this->pessoaModel->entityManager->find("Application\Model\Pessoa", $contato->getIdPessoa());
                $contato->setNomePessoa($pessoa->getNome());
            }
            return $contatos;
        }

        public function search($data,$view=null){
            $contato = $this->entityManager->getRepository('\Application\Model\Contato');
            if($view == 'index')
            {
                $query = $contato->createQueryBuilder('c');
                $resultQuery = $query->where('c.id = :data')
                ->andWhere($query->expr()->orX(
                    $query->expr()->like('c.tipo', ':data'),
                    $query->expr()->like('c.descricao', ':data')
                 ))
                ->setParameter('data', $data)
                ->getQuery()
                ->getResult();
            }
            else
            {
                $resultQuery = $this->entityManager->find('Application\Model\Contato', $data);
            }
            return $resultQuery;
        }

        public function new($data){
            $contato = new \Application\Model\Contato;
            $contato->setTipo($data['tipo']);
            $contato->setDescricao($data['descricao']);
            $contato->setIdPessoa($data['idPessoa']);
            $retorno = 1;
            try{
                $this->entityManager->persist($contato);
                $this->entityManager->flush();
            }
            catch(Exception $e) {
                $retorno = $e->getMessage();
            }

            return $this->verifyReturn($retorno);
        }

        public function edit($data){
            $retorno = 1;
            $contato = $this->entityManager->find("Application\Model\Contato", $data['id']);
            $contato->setTipo($data['tipo']);
            $contato->setDescricao($data['descricao']);
            $contato->setIdPessoa($data['idPessoa']);
            try{
                $this->entityManager->persist($contato);
                $this->entityManager->flush();
            }
            catch(Exception $e) {
                $retorno = $e->getMessage();
            }

            return $this->verifyReturn($retorno);
        }

        public function delete($id){ 
            $retorno = 1;
            if(!$this->search($id))
            {
                return false;
            }
            $contato = $this->entityManager->find("Application\Model\Contato", $id);

            try{
                $this->entityManager->remove($contato);
                $this->entityManager->flush();
            }
            catch(Exception $e) {
                $retorno = $e->getMessage();
            }

            return $this->verifyReturn($retorno);
        }

        public function verifyReturn($result){
            if($result == 1)
            {
                return true;
            }
            return false;
        }
    }

?>
