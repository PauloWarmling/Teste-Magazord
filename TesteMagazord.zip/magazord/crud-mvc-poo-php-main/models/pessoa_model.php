<?php

    require_once ("C:/xampp\htdocs/magazord 2/crud-mvc-poo-php-main/configuration/connect.php");
    require_once ("C:/xampp\htdocs/magazord 2/crud-mvc-poo-php-main/class/Pessoa.php");
    require_once "../vendor/autoload.php";

    use Doctrine\ORM\Tools\Setup;
    use Doctrine\ORM\EntityManager;

    class PessoaModel extends Connect{
        
        private $table;
        public $entityManager;

        function __construct(){
            parent::__construct();

            $paths = [__DIR__."/src/Entities"];
            $isDevMode = true;
            $config = Setup::createAnnotationMetadataConfiguration($paths, $isDevMode, null, null, false);

            //aqui configuramos a conexão com banco de dados
            $params = [
                'url' => "mysql://".USER.":".PASSWORD."@".HOST."/".DBNAME
            ];
            $this->entityManager = EntityManager::create($params, $config);
            $this->table = "pessoa";
        }

        public function getAll(){
            $pessoa = $this->entityManager->getRepository('\Application\Model\Pessoa');
            $resultQuery = $pessoa->findAll();
            return $resultQuery;
        }

        public function search($data,$view=null){
            $pessoa = $this->entityManager->getRepository('\Application\Model\Pessoa');
            if($view == 'index')
            {
                $where = is_int($data) ? "p.id = $data" : "p.nome LIKE '%$data%' OR p.cpf LIKE '%$data%'";
                $query = $pessoa->createQueryBuilder('p');
                $resultQuery = $query->where($where)
                ->getQuery()
                ->getResult();
                $fp = fopen('teste.txt', 'a+');
    fwrite($fp, print_r($resultQuery, true));
    fclose($fp);
            }
            else
            {
                $resultQuery = $this->entityManager->find('Application\Model\Pessoa', $data);
            }
            return $resultQuery;
        }

        public function new($data){
            $pessoa = new \Application\Model\Pessoa;
            $pessoa->setCpf($data['cpf']);
            $pessoa->setNome($data['nome']);
            $retorno = 1;
            try{
                $this->entityManager->persist($pessoa);
                $this->entityManager->flush();
            }
            catch(Exception $e) {
                $retorno = $e->getMessage();
            }

            return $this->verifyReturn($retorno);
        }

        public function edit($data){
            $retorno = 1;
            if(strlen($data['phone']) <= 11)
            {
                $pessoa = $this->entityManager->find("Application\Model\Pessoa", $data['id']);
                $pessoa->setNome($data['nome']);
                $pessoa->setCpf($data['cpf']);
                try{
                    $this->entityManager->persist($pessoa);
                    $this->entityManager->flush();
                }
                catch(Exception $e) {
                    $retorno = $e->getMessage();
                }
    
                return $this->verifyReturn($retorno);
            }
            return false;
        }

        public function delete($id){ 
            $retorno = 1;
            if(!$this->search($id))
            {
                return false;
            }
            $pessoa = $this->entityManager->find("Application\Model\Pessoa", $id);

            try{
                $this->entityManager->remove($pessoa);
                $this->entityManager->flush();
            }
            catch(Exception $e) {
                $retorno = $e->getMessage();
            }

            return $this->verifyReturn($retorno);
        }

        public function verifyReturn($result){
            if($result == 1)
            {
                return true;
            }
            return false;
        }
    }

?>
