<?php

    // $nameController = $_GET['c'];
    // include_once ('./controllers/'.$nameController.'Controller.php');
    require_once ('C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/controllers/pessoa_controller.php');
    require_once ('C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/controllers/contato_controller.php');

    $controllerPessoa = new PessoaController();
    $controllerContato = new ContatoController();
    $controller = isset($_GET['c']) && $_GET['c'] == 'contato' ? new ContatoController() : new PessoaController();
    $action = (isset($_GET['a']) || isset($_POST['a'])) ? (isset($_POST['a']) ? $_POST['a'] : $_GET['a']) : 'getAll';
    $message = isset($_GET['m']) ? $_GET['m'] : '';
    $status = !empty($_GET['s']) ? $_GET['s'] : '';
    if(!empty($message) && isset($_GET['s']))
    {
        $messages = [
            'edit' => ['editado','editar'],
            'delete' => ['deletado','deletar'],
            'update' => ['atualizado','atualizar'],
            'insert' => ['inserido','inserir']
        ];
        $controller->{$action}($messages[$message][0],$messages[$message][1],$status);
    }
    else if($action == "delete")
    {
        $id = $_GET['id'];
        $controller->{$action}($id);
    }
    else if($action == "search") {
        $selectPessoas = null;
        $data = $_GET['search'];
        $view = isset($_GET['v']) ? $_GET['v'] : 'index';
        if($view == 'editCreateContato') {
            $selectPessoas = $controllerPessoa->getAll(null, true);
        }
        if(empty($data))
        {
            $controller->getAll();
        }
        else
        {
            $controller->{$action}($data,$view,$selectPessoas);
        }
    }
    else if($action == "edit")
    {
        $controller->{$action}($_POST);
    }
    else if($action == "new")
    {
        $controller->{$action}($_POST);
    }
    else if($action == 'goToNewContato') {
        $data = $controllerPessoa->getAll(null, true);
        $controller->{$action}($data);
    }
    else if(!empty($action)) {
        $controller->{$action}($_POST);
    }
    else
    {
        $controller->getAll();
    }