<?php

    require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/models/contato_model.php");
    class ContatoController{

        private $model;

        function __construct(){
            $this->model = new ContatoModel();
        }

        public function getAll($data=null){
            $resultContato = $this->model->getAll();
            $returnMessage = $data;
            require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/views/index.php");
        }

        public function search($data,$view=null,$pessoas = null){
            $selectPessoas = $pessoas;
            $resultContato = $this->model->search($data,$view);
            require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/views/$view.php");
        }
        public function goToNewContato($data){
            $selectPessoas = $data;
            require_once ("./views/editCreateContato.php");
        }

        public function new($data){
            $result = $this->model->new($data);
            $this->redirectWithMessage('insert',$result);
        }

        public function edit($data){
            $result = $this->model->edit($data);
            $this->redirectWithMessage('edit',$result);
        }

        public function delete($id){
            $result = $this->model->delete($id);
            $this->redirectWithMessage('delete',$result);
        }

        public function redirectWithMessage($type,$result){
            header("Location: index.php?m=$type&a=showMessage&s=$result");
        }

        public function showMessage($success,$error,$status){
            if($status == 1)
            {
                $returnMessage = "Registro $success com sucesso!";
            }
            else
            {
                $returnMessage = "Erro ao $error!";
            }
            $this->getAll($returnMessage);
        }
    }

?>
