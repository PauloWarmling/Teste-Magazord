<?php

    require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/models/pessoa_model.php");
    require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/models/contato_model.php");
    class PessoaController{

        private $model;

        function __construct(){
            $this->model = new PessoaModel();
            $this->modelContato = new ContatoModel();
        }

        public function getAll($data=null, $return = false){
            $resultPessoa = $this->model->getAll();
            $resultContato = $this->modelContato->getAll();
            $returnMessage = $data;
            if(!$return) {
                require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/views/index.php");
            }
            else {
                return $resultPessoa;
            }
        }

        public function search($data,$view=null){
            $resultPessoa = $this->model->search($data,$view);
            $resultContato = $this->modelContato->getAll();
            require_once ("C:/xampp/htdocs/magazord 2/crud-mvc-poo-php-main/views/$view.php");
        }

        public function goToNewPessoa(){
            require_once ("./views/editCreatePessoa.php");
        }

        public function new($data){
            $result = $this->model->new($data);
            $this->redirectWithMessage('insert',$result);
        }

        public function edit($data){
            $result = $this->model->edit($data);
            $this->redirectWithMessage('edit',$result);
        }

        public function delete($id){
            $result = $this->model->delete($id);
            $this->redirectWithMessage('delete',$result);
        }

        public function redirectWithMessage($type,$result){
            header("Location: index.php?m=$type&a=showMessage&s=$result");
        }

        public function showMessage($success,$error,$status){
            if($status == 1)
            {
                $returnMessage = "Registro $success com sucesso!";
            }
            else
            {
                $returnMessage = "Erro ao $error!";
            }
            $this->getAll($returnMessage);
        }
    }

?>
