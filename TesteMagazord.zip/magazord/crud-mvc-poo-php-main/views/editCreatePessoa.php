<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="views/css/index.css">
    <title>Pessoa</title>
</head>
<body>
    <a class="button btn-back" href="index.php">Voltar</a>
    <h1>Configuração de Pessoa</h1>
    <div class="content">
        <form action="index.php" method="POST">
            <div class="input-box">
                <label for="nome">nome:</label>
                <input class="input" type="text" placeholder="Nome" value="<?= (isset($resultPessoa)) ? $resultPessoa->getNome() : '' ?>" name="nome" required>
            </div>
            <br><br>
            <div class="input-box">
                <label for="cpf">cpf:</label>
                <input class="input" type="cpf" placeholder="Cpf" value="<?= (isset($resultPessoa)) ? $resultPessoa->getCpf() : '' ?>" name="cpf" required>
            </div>
            <br><br>
            <input type="hidden" name="a" value="<?= (isset($resultPessoa)) ? 'edit' : 'new' ?>">
            <input type="hidden" name="id" value="<?= (isset($resultPessoa)) ? $resultPessoa->getId() : '' ?>">
            <input class="button btn-search" type="submit" name="submit" value="Enviar">
        </form>
    </div>
</body>
</html>