<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="views/css/index.css">
    <title>Pessoa</title>
</head>
<body>
    <a class="button btn-back" href="index.php">Voltar</a>
    <h1>Configuração de Contato</h1>
    <div class="content">
        <form action="index.php?c=contato" method="POST">
            <div class="input-box">
                <label for="tipo">tipo:</label>
                <input class="input" type="text" placeholder="Tipo" value="<?= (isset($resultContato)) ? $resultContato->getTipo() : '' ?>" name="tipo" required>
            </div>
            <br><br>
            <div class="input-box">
                <label for="descricao">descrição:</label>
                <input class="input" type="descricao" placeholder="Descrição" value="<?= (isset($resultContato)) ? $resultContato->getDescricao() : '' ?>" name="descricao" required>
            </div>
            <br><br>
            <div class="input-box">
                <label for="idPessoa">Pessoa:</label>
                <select class="input" value="<?= (isset($resultContato)) ? $resultContato->getIdPessoa() : '' ?>" name="idPessoa" required>
                <option value=''>Selecione</option>
                <?php
                    if(count($selectPessoas) > 0) {
                        foreach($selectPessoas as $pessoa) {
                            $selected = (isset($resultContato)) && $pessoa->getId() == $resultContato->getIdPessoa() ? 'selected' : '';
                            echo "<option id='{$pessoa->getId()}' value='{$pessoa->getId()}' {$selected}>{$pessoa->getNome()}</option>";
                        }
                    }
                ?>
            </div>
            <br><br>
            <input type="hidden" name="a" value="<?= (isset($resultContato)) ? 'edit' : 'new' ?>">
            <input type="hidden" name="id" value="<?= (isset($resultContato)) ? $resultContato->getId() : '' ?>">
            <input class="button btn-search" type="submit" name="submit" value="Enviar">
        </form>
    </div>
</body>
</html>